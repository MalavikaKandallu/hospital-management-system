<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>FEEDBACKS</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body style='background-image:url(hospital.jpg); background-size:cover;  background-repeat: no-repeat;'>
    <header class='nheader'>
    <h2>NEW HOSPITAL</h2>
    <div class='nav2'>
    <nav class='navbar'>
    <a href='adminpage.php'>HOME</a>
    <a href='users.html'>LOGOUT</a>
    </nav></div>
    </header>
    <table class='table'>
                  <caption><h2 style='background-color: darkturquoise; margin: 10px 0px; border:2px solid black;'>FEEDBACKS</h2></caption>
                    <th class='head'>NAME</th>
                    <th class='head'>CONTACT NUMBER</th> 
                    <th class='head'>FEEDBACK</th>
<?php
include 'style.css';
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hospital";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT fname,cn,feed FROM feedback";
$result = $conn->query($sql);
$n = $result->num_rows;
if ($n > 0) {
  // output data of each row   
  while($row = $result->fetch_assoc()) { 
                $d1=$row['fname'];
                $d2=$row['cn'];                
                $d3=$row['feed'];
                echo"
                 
                    <tr class='headert'> 
                    <td class='headert'>$d1</td>  
                    <td class='headert'>$d2</td> 
                    <td class='headert'>$d3</td>
                    </tr>";
                    }
                   }
else{
  echo "NO FEEBACKS";
} 
                ?>
  
</body>";
</html>