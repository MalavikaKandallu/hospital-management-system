<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>ADMIN DESK</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body style="background-image:url(hospital.jpg); background-size:cover;  background-repeat: no-repeat;">
	<header class="nheader">
    <h2>NEW HOSPITAL</h2>
    <div class='nav2'>
    <nav class='navbar'>
    <a href='users.html'>LOGOUT</a>
    </nav></div>
    </header>
    <div class="container1">
    	<div class="card1">
    		<center><img src="doctor.jpg"><br>
    			<a href="add.php"><button class="opt" onclick="add.php">ADD DOCTOR</button></a></center>
    		</div>
    		<div class="card1">
    		<center><img src="feedback.jpg"><br>
    			<a href="feedback.php"><button class="opt">VIEW FEEDBACK</button></a></center>
    		</div>
    	</div>


</body>
</html>