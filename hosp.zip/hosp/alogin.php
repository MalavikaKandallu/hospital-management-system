<?php  
        $user=$_POST['uname'];  
        $pass=$_POST['psw'];  
      
        $con=mysqli_connect('localhost','root','') or die(mysql_error());  
        mysqli_select_db($con,'hospital') or die("cannot select DB");  
      
        $query=mysqli_query($con,"SELECT * FROM administrator WHERE user='".$user."' AND pass='".$pass."'");  
        $numrows=mysqli_num_rows($query);  
        if($numrows!=0)  
        {  
        while($row=mysqli_fetch_assoc($query))  
        {  
        $dbusername=$row['user'];  
        $dbpassword=$row['pass'];  
        }  
      
        if($user == $dbusername && $pass == $dbpassword)  
        {  
       header("refresh:0;url=adminpage.php");
        }
         else {  
        echo "Invalid username or password!";  
        }  
    }
     
    ?>