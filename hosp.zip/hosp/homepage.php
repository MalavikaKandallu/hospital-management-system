<?php    
 
    $name=$_POST['fname'];  
        $address=$_POST['address'];  
$mno=$_POST['mno'];  
        $dappoint=$_POST['dappoint'];
$tappoint=$_POST['tappoint'];  
    $con=mysqli_connect('localhost','root','') or die(mysql_error());  
    mysqli_select_db($con,'hospital') or die("cannot select DB");  
 

    $sql="INSERT INTO appointment(fname,Address,Mobile_number,doa,toa) VALUES('$name','$address','$mno','$dappoint','$tappoint')";  
 
    $result=mysqli_query($con,$sql);  
        if($result==true){  
                       echo" Appointment booked successfully!";
  header("refresh:1;url=appointment.html");
    } else {  
    echo "Failure!";  
    }  
 

 
 
?>  