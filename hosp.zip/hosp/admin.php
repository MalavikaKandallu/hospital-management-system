<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>hospital management system</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body style="background-image:url(hospital.jpg); background-size:cover;  background-repeat: no-repeat;">
	<div class="login-form">
	<div class="container">
	  <div class="card">
		<h1 type="text" class="header">ADMIN LOGIN</h1>
		<form action="alogin.php" method="post">
		<input type="user" name="uname" placeholder="User ID" class="name"><br>
<br>
		<input type="password" name="psw"placeholder="Password" class="name">
<br>
		<button type="login"  class="button">Login</button>

</body>
</html>
