-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 02, 2022 at 06:36 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hospital`
--

-- --------------------------------------------------------

--
-- Table structure for table `administrator`
--

CREATE TABLE `administrator` (
  `user` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `administrator`
--

INSERT INTO `administrator` (`user`, `pass`) VALUES
('m', 'm');

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `fname` varchar(50) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `Mobile_number` int(50) NOT NULL,
  `doa` date NOT NULL,
  `toa` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`fname`, `Address`, `Mobile_number`, `doa`, `toa`) VALUES
('m', 'm', 1, '2022-05-26', '22:05:00');

-- --------------------------------------------------------

--
-- Table structure for table `docl`
--

CREATE TABLE `docl` (
  `s.no` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `docl`
--

INSERT INTO `docl` (`s.no`, `username`, `password`, `name`) VALUES
(1, 'd', 'd', 'Guru'),
(2, 'malz', 'malz', 'Malavika');

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `s.np` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `qual` varchar(50) NOT NULL,
  `yoe` varchar(50) NOT NULL,
  `spi` varchar(50) NOT NULL,
  `cn` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`s.np`, `username`, `fname`, `lname`, `qual`, `yoe`, `spi`, `cn`, `address`) VALUES
(1, 'd', 'Guru', 'Gladdy', 'MBBS', '3', 'Heart surgeon', '1234567899', 'auyub wdgqy28   '),
(2, 'malz', 'Malavika', 'K.R.', 'MBBS', '21', 'BRAIN SURGEON', '272741922', 'AKBHBSDIQ 8E28DNX ASKN');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `feed` varchar(100) NOT NULL,
  `cn` int(100) NOT NULL,
  `address` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`fname`, `lname`, `feed`, `cn`, `address`) VALUES
('e', 'e', '2', 1111111111, 'e'),
('malavika', 'kandallu', 'good', 1234567890, 'sank'),
('', '', '', 0, ''),
('', '', '', 0, ''),
('', '', '', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `user` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`user`, `pass`, `name`) VALUES
('p', 'p', ''),
('', '', ''),
('g', 'g', 'g');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `docl`
--
ALTER TABLE `docl`
  ADD PRIMARY KEY (`s.no`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`s.np`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `docl`
--
ALTER TABLE `docl`
  MODIFY `s.no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `s.np` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
