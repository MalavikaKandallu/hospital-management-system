<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>DOCTOR DETAILS</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <style>
#details {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
  font-size: 20px;
}

#details td, #details th {
  border: 1px solid #ddd;
  padding: 15px;
}

#details tr:nth-child(even){background-color: #f2f2f2;}
#details tr:nth-child(odd){background-color: #b9a7a5;}

#details th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #04AA6D;
  color: white;
}
</style>
</head>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hospital";
session_start();
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$name=$_SESSION["username"];
$query=mysqli_query($conn,"SELECT * FROM doctor WHERE fname='".$name."'");  
        $numrows=mysqli_num_rows($query);  
        if($numrows!=0)  
        {  
        while($row=mysqli_fetch_assoc($query))  
        {  
        $d1=$row['fname'];
        $d2=$row['qual'];
        $d3=$row['yoe'];
        $d4=$row['spi'];
        $d5=$row['cn'];
        $d6=$row['address'];  
        }  
      }

echo"
<body style='background-image:url(hospital.jpg); background-size:cover;  background-repeat: no-repeat;'>
  <header class='nheader'>
    <h2>NEW HOSPITAL</h2>
    <div class='nav2'>
    <nav class='navbar'>
    <a href='#'>$name</a>
    <a href='users.html'>LOGOUT</a>
    </nav></div>
    </header>
    <div class='container1'>
    <div style='background-color:white' class='form'>
    <center><h1 style='background-color:lightblue'>DOCTOR DETAILS</h1></center>
<table id='details'>
  <tr>
    <th>Name</th>
    <td>$d1</td>
  </tr>
  <tr>
    <th>Qualification</th>
    <td>$d2</td>
  </tr>
  <tr>
    <th>Years Of Experience</th>
    <td>$d3</td>
  </tr>
  <tr>
    <th>Specialized In</th>
    <td>$d4</td>
  </tr>
  <tr>
    <th>Contact No</th>
    <td>$d5</td>
  </tr>
  <tr>
    <th>Address</th>
    <td>$d6</td>
  </tr>
</table>

</div>
</div>

    </body>";
    ?>

</html>