<?php  
        $fname=$_POST['fname']; 
	$lname=$_POST['lname'];
        $qual=$_POST['qual'];  
	$yoe=$_POST['yoe'];  
        $spi=$_POST['spi'];
	$cn=$_POST['cn'];  
        $address=$_POST['address'];
      
        $con=mysqli_connect('localhost','root','') or die(mysql_error());  
        mysqli_select_db($con,'hospital') or die("cannot select DB");  
      
        $query="INSERT INTO doctor(fname,lname,qual,yoe,spi,cn,address) VALUES('$fname','$lname','$qual','$yoe','$spi','$cn','$address')";  
       $result=mysqli_query($con,$query);  
        if($result==true){  
                      
                      echo "New Doctor Added Successfully!";  
  header("refresh:1;url=add.php");

    } else {  
    echo "Failure!";  
    }  
?>  
