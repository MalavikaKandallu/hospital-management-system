<?php    
 
    $name=$_POST['name'];  
        $feed=$_POST['feed'];  
    $con=mysqli_connect('localhost','root','') or die(mysql_error());  
    mysqli_select_db($con,'train') or die("cannot select DB");  
 

    $sql="INSERT INTO home(Name,) VALUES('$name','$feed')";  
 
    $result=mysqli_query($con,$sql);  
        if($result==true){  
                       
  header("refresh:1;url=payment.php");
    } else {  
    echo "Failure!";  
    }  
 

 
 
?>  