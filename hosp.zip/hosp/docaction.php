<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>DOCTOR</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hospital";
session_start();
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$name=$_SESSION["username"];
$_SESSION["username"]=$name;
echo"<body style='background-image:url(hospital.jpg); background-size:cover;  background-repeat: no-repeat;'>
	<header class='nheader'>
    <h2>NEW HOSPITAL</h2>
    <div class='nav2'>
    <nav class='navbar'>
    <a href='#'>$name</a>
    <a href='doclogin.html'>LOGOUT</a>
    </nav></div>
    </header>
    <div class='container1'>
    	<div class='card1'>
    		<center><img src='appointment.png'><br>
    			<a href='docappointments.php'><button class='opt' onclick='docappointments.php'>MY APPOINTMENTS</button></a></center>
    		</div>
    		<div class='card1'>
    		<center><img src='profile.png'><br>
    			<a href='docdetails.php'><button class='opt'>MY DETAILS</button></a></center>
    		</div>
    	</div>
</body>";
?>
</html>