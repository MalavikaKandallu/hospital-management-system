<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>ADD DOCTOR</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body style="background-image:url(hospital.jpg); background-size:cover;  background-repeat: no-repeat;">
	<header class="nheader">
    <h2>NEW HOSPITAL</h2>
    <div class='nav2'>
    <nav class='navbar'>
    <a href='adminpage.php'>HOME</a>
    <a href='users.html'>LOGOUT</a>
    </nav></div>
    </header>
   <div class="container1">
   	<div class="form">
  	<form action="action_page.php" method="post">
    <label for="fname">First Name</label>
    <input type="text" id="fname" name="fname" required>

    <label for="lname">Last Name</label>
    <input type="text" id="lname" name="lname" required>

    <label for="fname">Qualification</label>
    <input type="text" id="qual" name="qual" required>

    <label for="fname">Year of Experience</label>
    <input type="text" id="yoe" name="yoe" required>

	<label for="fname">Specialized In</label>
    <input type="text" id="spi" name="spi" required>

	<label for="fname">Contact no</label>
    <input type="text" id="cn" name="cn" title="Invalid Number" pattern="[1-9]{1}[0-9]{9}" required>
    
    <label for="fname">Address</label>
    <input type="text" id="address" name="address" required>

    <input type="submit" value="Submit">
  </form>
</div>
</div>

</body>
</html>