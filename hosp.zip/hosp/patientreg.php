<?php    
    $name=$_POST['name'];
    $user=$_POST['uname'];  
    $pass=$_POST['psw'];  
    $pass1=$_POST['psw1'];  
    $con=mysqli_connect('localhost','root','') or die(mysql_error());  
    mysqli_select_db($con,'hospital') or die("cannot select DB");  
  
    $query=mysqli_query($con,"SELECT * FROM patient WHERE user='".$user."'");  
    $numrows=mysqli_num_rows($query);  
    if($numrows==0)  
    {
    	if($pass==$pass1)
	{  
    	$sql="INSERT INTO patient(user,pass,name) VALUES('$user','$pass','$name')";  
   	$result=mysqli_query($con,$sql);  
        	if($result)
		{                        
    		echo "Account Successfully Created";  
   		header("refresh:1;url=patient.html");
    		}
    		else
		{ 
   		echo "Failure!";  
    		header("refresh:1;url=patreg.html");
   		}  
  	} 
        else 
	{
	echo "Passwords does not match";
	}
     
  }
  else
  {  
    echo "That username already exists! Please try again with another.";  
    header("refresh:1;url=patreg.html");
  }  
 
?>  
