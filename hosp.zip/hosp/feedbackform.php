<?php  
        $fname=$_POST['fname']; 
	$lname=$_POST['lname'];
        $cn=$_POST['cn'];  
	$address=$_POST['address'];  
        $feed=$_POST['feed'];

        $con=mysqli_connect('localhost','root','') or die(mysql_error());  
        mysqli_select_db($con,'hospital') or die("cannot select DB");  
      
        $query="INSERT INTO feedback(fname,lname,cn,address,feed) VALUES('$fname','$lname','$cn','$address','$feed')";  
       $result=mysqli_query($con,$query);  
        if($result==true){  
                      
                      echo "Feedback added successfully!";  
  header("refresh:1;url=feedbackform.html");

    } else {  
    echo "Failure!";  
    }  
?>  
